#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "llist.h"

char * eval (char ** input, size_t length)
{
	//TODO
}

int main ()
{
	char * input [] = {"a", "b", "2", "+", "2"} ;
	char * r ;

	r = eval(input, 5) ;

	printf("%s\n", r) ;

	free(r) ;

	return 0 ;
}
